import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { TransformControls } from "three/examples/jsm/controls/TransformControls.js";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import { OBJLoader } from "three/examples/jsm/loaders/OBJLoader.js";
import { STLLoader } from "three/examples/jsm/loaders/STLLoader.js";
import { GLTFExporter } from "three/examples/jsm/exporters/GLTFExporter.js";
import { OBJExporter } from "three/examples/jsm/exporters/OBJExporter.js";
import { STLExporter } from "three/examples/jsm/exporters/STLExporter.js";
import { Plus, Trash2, Copy, Undo2, Redo2, Download, Upload, Save, HelpCircle, Home, FolderOpen, Move, RotateCw, Maximize2, MousePointer2, Eye, EyeOff, Lock, Unlock, X, Sun, Moon, Camera, Layers, Ruler, Building2, DoorOpen, Square, Circle, Box, Cylinder, Cone, Triangle, FileText, Info, ExternalLink, Check, AlertTriangle, Folder, FilePlus, ChevronRight, Grid3X3, Lightbulb } from "lucide-react";

type Vec3 = { x: number; y: number; z: number };
type MatState = { color: string; roughness: number; metalness: number; opacity: number; wireframe: boolean };
type ObjType = "box"|"sphere"|"cylinder"|"cone"|"torus"|"plane"|"wall"|"floor"|"door"|"window"|"column"|"stairs"|"roof"|"group"|"imported";
type SceneObj = { id: string; name: string; type: ObjType; position: Vec3; rotation: Vec3; scale: Vec3; material: MatState; visible: boolean; locked: boolean; parentId: string|null; params: Record<string, number> };
type LightState = { hemiIntensity: number; hemiColor: string; dirIntensity: number; dirColor: string; dirPos: Vec3; shadows: boolean };
type ProjectRecord = { id: string; value: { name: string; schemaVersion: number; objects: SceneObj[]; updatedAt: string }; created_at: string; updated_at: string };
const SCHEMA_VERSION = 1;
const uid = () => Math.random().toString(36).slice(2,9) + Date.now().toString(36).slice(-4);
const defaultMat = (color="#7f8ea3"): MatState => ({ color, roughness: 0.75, metalness: 0.05, opacity: 1, wireframe: false });
const cloneObjs = (o: SceneObj[]) => JSON.parse(JSON.stringify(o)) as SceneObj[];
function migrateProject(input: any): SceneObj[] {
  if (!input) return [];
  const arr = Array.isArray(input) ? input : input.objects || [];
  return arr.filter((o:any)=>o && typeof o.id==="string" && typeof o.name==="string").map((o:any)=>({
    id: o.id, name: o.name, type: (o.type||"box") as ObjType,
    position: o.position||{x:0,y:0.5,z:0}, rotation: o.rotation||{x:0,y:0,z:0}, scale: o.scale||{x:1,y:1,z:1},
    material: { color: o.material?.color||"#7f8ea3", roughness: Number(o.material?.roughness??0.75), metalness: Number(o.material?.metalness??0.05), opacity: Number(o.material?.opacity??1), wireframe: !!o.material?.wireframe },
    visible: o.visible!==false, locked: !!o.locked, parentId: o.parentId||null, params: o.params||{}
  }));
}
async function api(action: string, args: any){
  const res = await fetch("actions", { method:"POST", headers:{ "content-type":"application/json" }, body: JSON.stringify({ action, args }) });
  const j = await res.json().catch(()=>({}));
  if(!res.ok || j.error) throw new Error(j.error || ("Request failed: "+res.status));
  return j.data;
}
function downloadBlob(blob: Blob, filename: string){
  const url = URL.createObjectURL(blob); const a=document.createElement("a"); a.href=url; a.download=filename; document.body.appendChild(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(url),1000);
}
function typeLabel(t: ObjType){ return t==="floor"?"Floor / slab": t==="window"?"Window": t.charAt(0).toUpperCase()+t.slice(1); }
function newPrimitive(type: ObjType, idx: number): SceneObj {
  const base: SceneObj = { id: uid(), name: `${typeLabel(type)} ${idx}`, type, position:{x:0,y:0.6,z:0}, rotation:{x:0,y:0,z:0}, scale:{x:1,y:1,z:1}, material: defaultMat(), visible:true, locked:false, parentId:null, params:{} };
  if(type==="plane"){ base.position.y=0.01; base.rotation.x=0; }
  if(type==="wall"){ base.params={length:4,height:2.8,thickness:0.2}; base.position.y=1.4; base.material=defaultMat("#d8d3c3"); }
  if(type==="floor"){ base.params={width:5,thickness:0.2,depth:5}; base.position.y=0; base.material=defaultMat("#b9a98c"); }
  if(type==="door"){ base.params={width:0.9,height:2.1,thickness:0.08}; base.position.y=1.05; base.material=defaultMat("#8a5a2b"); }
  if(type==="window"){ base.params={width:1.2,height:1.2,thickness:0.08}; base.position.y=1.5; base.material=defaultMat("#9fd8e8"); }
  if(type==="column"){ base.params={radius:0.18,height:2.8}; base.position.y=1.4; base.material=defaultMat("#e6e2d8"); }
  if(type==="stairs"){ base.params={steps:6,rise:0.18,run:0.28,width:1}; base.position.y=0; base.material=defaultMat("#c9b896"); }
  if(type==="roof"){ base.params={width:5,depth:4,height:1.2,style:1}; base.position.y=3.4; base.material=defaultMat("#7a3b2e"); }
  return base;
}
function buildGeometry(o: SceneObj, importedGeo?: THREE.BufferGeometry): THREE.BufferGeometry | null {
  const p=o.params;
  switch(o.type){
    case "box": return new THREE.BoxGeometry(1,1,1);
    case "sphere": return new THREE.SphereGeometry(0.5,32,32);
    case "cylinder": return new THREE.CylinderGeometry(0.5,0.5,1,32);
    case "cone": return new THREE.ConeGeometry(0.5,1,32);
    case "torus": return new THREE.TorusGeometry(0.5,0.18,16,48);
    case "plane": return new THREE.PlaneGeometry(2,2);
    case "wall": return new THREE.BoxGeometry(p.length||4,p.height||2.8,p.thickness||0.2);
    case "floor": return new THREE.BoxGeometry(p.width||5,p.thickness||0.2,p.depth||5);
    case "door": return new THREE.BoxGeometry(p.width||0.9,p.height||2.1,p.thickness||0.08);
    case "window": return new THREE.BoxGeometry(p.width||1.2,p.height||1.2,p.thickness||0.08);
    case "column": return new THREE.CylinderGeometry(p.radius||0.18,p.radius||0.18,p.height||2.8,24);
    case "imported": return importedGeo ? importedGeo.clone() : new THREE.BoxGeometry(1,1,1);
    default: return new THREE.BoxGeometry(1,1,1);
  }
}
function buildObject3D(o: SceneObj, importedGeo?: THREE.BufferGeometry): THREE.Object3D {
  if(o.type==="stairs"){
    const g=new THREE.Group(); const steps=Math.max(1,Math.round(o.params.steps||6)); const rise=o.params.rise||0.18, run=o.params.run||0.28, w=o.params.width||1;
    for(let i=0;i<steps;i++){ const m=new THREE.Mesh(new THREE.BoxGeometry(run, rise*(i+1), w)); m.position.set(run*i, rise*(i+1)/2, 0); g.add(m); }
    return g;
  }
  if(o.type==="roof"){
    const g=new THREE.Group(); const w=o.params.width||5, d=o.params.depth||4, h=o.params.height||1.2;
    if((o.params.style||1)===0){ const m=new THREE.Mesh(new THREE.BoxGeometry(w,0.18,d)); g.add(m); return g; }
    const slope=Math.sqrt((w/2)*(w/2)+h*h); const ang=Math.atan2(h,w/2);
    const left=new THREE.Mesh(new THREE.BoxGeometry(slope,0.12,d)); left.position.set(-w/4, h/2, 0); left.rotation.z=ang; const right=new THREE.Mesh(new THREE.BoxGeometry(slope,0.12,d)); right.position.set(w/4,h/2,0); right.rotation.z=-ang; g.add(left,right); return g;
  }
  if(o.type==="group") return new THREE.Group();
  const geo=buildGeometry(o, importedGeo); if(!geo) return new THREE.Group();
  return new THREE.Mesh(geo);
}
function templateObjects(kind: string): SceneObj[] {
  if(kind==="Room"){
    const wall1={...newPrimitive("wall",1), name:"North wall", position:{x:0,y:1.4,z:-2.5}}; const wall2={...newPrimitive("wall",2), name:"South wall", position:{x:0,y:1.4,z:2.5}};
    const floor={...newPrimitive("floor",1), name:"Room floor", position:{x:0,y:0,z:0}}; const door={...newPrimitive("door",1), name:"Room door", position:{x:-1,y:1.05,z:-2.45}};
    const win={...newPrimitive("window",1), name:"Room window", position:{x:1.2,y:1.5,z:-2.45}}; const table={...newPrimitive("box",1), name:"Table top", position:{x:0,y:0.75,z:0}, scale:{x:1.6,y:0.08,z:0.9}, material:defaultMat("#a67c4d")};
    return [floor, wall1, wall2, door, win, table];
  }
  if(kind==="House"){
    const floor={...newPrimitive("floor",1), name:"House slab", params:{width:7,thickness:0.25,depth:6}, position:{x:0,y:0,z:0}};
    const w1={...newPrimitive("wall",1), name:"Front wall", params:{length:7,height:2.8,thickness:0.2}, position:{x:0,y:1.4,z:-3}};
    const w2={...newPrimitive("wall",2), name:"Back wall", params:{length:7,height:2.8,thickness:0.2}, position:{x:0,y:1.4,z:3}};
    const w3={...newPrimitive("wall",3), name:"Left wall", params:{length:6,height:2.8,thickness:0.2}, position:{x:-3.5,y:1.4,z:0}, rotation:{x:0,y:Math.PI/2,z:0}};
    const w4={...newPrimitive("wall",4), name:"Right wall", params:{length:6,height:2.8,thickness:0.2}, position:{x:3.5,y:1.4,z:0}, rotation:{x:0,y:Math.PI/2,z:0}};
    const roof={...newPrimitive("roof",1), name:"Gable roof", params:{width:7.6,depth:6.6,height:1.4,style:1}, position:{x:0,y:2.8,z:0}};
    const door={...newPrimitive("door",1), name:"Front door", position:{x:0,y:1.05,z:-2.9}};
    const col={...newPrimitive("column",1), name:"Porch column", position:{x:2.5,y:1.4,z:-3.8}};
    return [floor,w1,w2,w3,w4,roof,door,col];
  }
  if(kind==="Building"){
    const objs: SceneObj[]=[]; const slab={...newPrimitive("floor",1), name:"Base slab", params:{width:10,thickness:0.4,depth:8}, position:{x:0,y:0,z:0}}; objs.push(slab);
    for(let i=0;i<3;i++){ const level={...newPrimitive("box",i+1), name:`Level ${i+1}`, position:{x:0,y:1.6+i*3,z:0}, scale:{x:8,y:3,z:6}, material:defaultMat(i===1?"#9fb2c8":"#c7cdd4")}; objs.push(level); }
    objs.push({...newPrimitive("roof",1), name:"Building roof", params:{width:8.5,depth:6.5,height:0.2,style:0}, position:{x:0,y:10.1,z:0}});
    return objs;
  }
  if(kind==="Table"){
    const top={...newPrimitive("box",1), name:"Table top", position:{x:0,y:0.75,z:0}, scale:{x:1.8,y:0.08,z:1}, material:defaultMat("#a67c4d")};
    const legs: SceneObj[]=[]; [[-0.8,-0.4],[0.8,-0.4],[-0.8,0.4],[0.8,0.4]].forEach(([x,z],i)=> legs.push({...newPrimitive("box",i+2), name:`Leg ${i+1}`, position:{x,y:0.36,z}, scale:{x:0.08,y:0.72,z:0.08}, material:defaultMat("#5b4630")}));
    return [top,...legs];
  }
  return [];
}
class Boundary extends React.Component<{children:React.ReactNode},{err:string|null}>{
  state={err:null as string|null}; static getDerivedStateFromError(e:any){ return {err: e?.message||"Something went wrong"}; }
  render(){ if(this.state.err) return <div style={{padding:24}}><h2>Studio could not start</h2><p>{this.state.err}</p><p>Try reloading the page. Your project list is on the Projects screen.</p></div>; return this.props.children; }
}
function Toast({msg}:{msg:string}){ return <div className="toast" role="status">{msg}</div>; }

export default function App(){
  const [hash,setHash]=useState(()=> window.location.hash || "#/studio");
  useEffect(()=>{ const f=()=> setHash(window.location.hash || "#/studio"); window.addEventListener("hashchange",f); return ()=> window.removeEventListener("hashchange",f); },[]);
  const [theme,setTheme]=useState<"dark"|"light">("dark");
  const [toast,setToast]=useState("");
  const showToast=(m:string)=>{ setToast(m); setTimeout(()=>setToast(""),3200); };
  const [projectName,setProjectName]=useState("Untitled Project");
  const [currentProjectId,setCurrentProjectId]=useState<string|null>(null);
  const [objects,setObjects]=useState<SceneObj[]>([]);
  const [selected,setSelected]=useState<string[]>([]);
  const [tool,setTool]=useState<"select"|"translate"|"rotate"|"scale">("select");
  const [space,setSpace]=useState<"local"|"world">("world");
  const [snapOn,setSnapOn]=useState(true);
  const [snapStep,setSnapStep]=useState(0.5);
  const [camMode,setCamMode]=useState<"persp"|"ortho">("persp");
  const [bgPreset,setBgPreset]=useState<"dark"|"light"|"studio">("dark");
  const [showGrid,setShowGrid]=useState(true);
  const [showAxes,setShowAxes]=useState(true);
  const [lights,setLights]=useState<LightState>({ hemiIntensity:0.7, hemiColor:"#dfeaff", dirIntensity:1.4, dirColor:"#ffffff", dirPos:{x:5,y:8,z:4}, shadows:true });
  const [history,setHistory]=useState<SceneObj[][]>([]); const [redoStack,setRedoStack]=useState<SceneObj[][]>([]);
  const [clipboard,setClipboard]=useState<SceneObj[]>([]);
  const [saveState,setSaveState]=useState("Not saved yet");
  const [projects,setProjects]=useState<ProjectRecord[]>([]);
  const [projectsLoading,setProjectsLoading]=useState(false);
  const [projectsError,setProjectsError]=useState("");
  const [inspectorTab,setInspectorTab]=useState<"transform"|"material"|"lights"|"arch">("transform");
  const [leftOpen,setLeftOpen]=useState(false); const [rightOpen,setRightOpen]=useState(false);
  const [showShortcuts,setShowShortcuts]=useState(false); const [showExport,setShowExport]=useState(false); const [showImportInfo,setShowImportInfo]=useState(false);
  const [exportFormat,setExportFormat]=useState<"glb"|"gltf"|"obj"|"stl"|"png"|"json">("glb"); const [exportScope,setExportScope]=useState<"all"|"selected">("all");
  const [confirmClear,setConfirmClear]=useState(false); const [renameId,setRenameId]=useState<string|null>(null); const [renameVal,setRenameVal]=useState("");
  const [fps,setFps]=useState(0); const [triangles,setTriangles]=useState(0); const [drawCalls,setDrawCalls]=useState(0);
  const [hintDismissed,setHintDismissed]=useState(false);
  const [webglError,setWebglError]=useState("");
  const [importStatus,setImportStatus]=useState("");
  const [busy,setBusy]=useState(false);

  const objectsRef=useRef(objects); objectsRef.current=objects;
  const selectedRef=useRef(selected); selectedRef.current=selected;
  const toolRef=useRef(tool); toolRef.current=tool;
  const spaceRef=useRef(space); spaceRef.current=space;
  const camModeRef=useRef(camMode); camModeRef.current=camMode;
  const engineRef=useRef<any>(null);
  const mapRef=useRef(new Map<string, THREE.Object3D>());
  const matMapRef=useRef(new Map<string, THREE.Material>());
  const geoMapRef=useRef(new Map<string, THREE.BufferGeometry>());
  const helperMapRef=useRef(new Map<string, THREE.Object3D>());
  const historyRef=useRef(history); historyRef.current=history;
  const pushHistory=(prev: SceneObj[])=>{ setHistory(h=>{ const n=[...h, cloneObjs(prev)]; return n.length>100? n.slice(n.length-100): n; }); setRedoStack([]); };
  const applyObjects=(next: SceneObj[], record=true)=>{ if(record) pushHistory(objectsRef.current); setObjects(next); };
  const loadProjects=useCallback(async()=>{
    setProjectsLoading(true); setProjectsError("");
    try{ const data:any= await api("records.list", { collection:"toolsx3d-projects" }); const recs=(data.records||[]) as ProjectRecord[]; setProjects(recs); }
    catch(e:any){ setProjectsError("Projects could not be loaded. The save service is unavailable right now."); }
    setProjectsLoading(false);
  },[]);
  useEffect(()=>{ loadProjects(); },[loadProjects]);

  // Autosave current project
  const skipSaveRef=useRef(false);
  useEffect(()=>{
    if(!currentProjectId) return; if(skipSaveRef.current){ skipSaveRef.current=false; return; }
    setSaveState("Saving…"); const t=setTimeout(async()=>{
      try{ const cur=projects.find(p=>p.id===currentProjectId); await api("records.replace", { collection:"toolsx3d-projects", id: currentProjectId, value:{ name: projectName, schemaVersion: SCHEMA_VERSION, objects: objectsRef.current, updatedAt: new Date().toISOString() } }); setSaveState("Saved"); if(cur) loadProjects(); }
      catch{ setSaveState("Save unavailable — export a backup"); }
    },900); return ()=> clearTimeout(t);
  },[objects, projectName, currentProjectId]);

  useEffect(()=>{
    const onBeforeUnload=(e: BeforeUnloadEvent)=>{ if(currentProjectId && saveState==="Saving…"){ e.preventDefault(); e.returnValue=""; } }; window.addEventListener("beforeunload", onBeforeUnload); return ()=> window.removeEventListener("beforeunload", onBeforeUnload);
  },[currentProjectId, saveState]);

  const selectedObjs=useMemo(()=> objects.filter(o=> selected.includes(o.id)),[objects,selected]);
  const primary=selectedObjs[0];

  // ---- THREE setup once ----
  const viewportRef=useRef<HTMLDivElement>(null);
  useEffect(()=>{
    if(!viewportRef.current) return;
    let renderer: THREE.WebGLRenderer;
    try{ renderer=new THREE.WebGLRenderer({ antialias:true, preserveDrawingBuffer:true }); } catch(e:any){ setWebglError("WebGL is not supported in this browser. Try a modern browser with hardware acceleration enabled."); return; }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio,2)); renderer.shadowMap.enabled=true; renderer.shadowMap.type=THREE.PCFSoftShadowMap; renderer.outputColorSpace=THREE.SRGBColorSpace;
    const container=viewportRef.current; container.appendChild(renderer.domElement); renderer.domElement.style.display="block"; renderer.domElement.style.width="100%"; renderer.domElement.style.height="100%"; renderer.domElement.style.touchAction="none";
    const scene=new THREE.Scene(); scene.background=new THREE.Color("#101214");
    const persp=new THREE.PerspectiveCamera(50,1,0.1,200); persp.position.set(5,4,6);
    const ortho=new THREE.OrthographicCamera(-5,5,5,-5,0.1,200); ortho.position.set(5,4,6);
    const grid=new THREE.GridHelper(20,20,0x2e8f6a,0x2a2f36); scene.add(grid);
    const axes=new THREE.AxesHelper(2); scene.add(axes);
    const hemi=new THREE.HemisphereLight(0xdfeaff,0x1a1a1a,0.7); scene.add(hemi);
    const dir=new THREE.DirectionalLight(0xffffff,1.4); dir.position.set(5,8,4); dir.castShadow=true; dir.shadow.mapSize.set(2048,2048); scene.add(dir);
    const ambient=new THREE.AmbientLight(0xffffff,0.15); scene.add(ambient);
    const orbit=new OrbitControls(persp, renderer.domElement); orbit.enableDamping=true; orbit.dampingFactor=0.08; orbit.target.set(0,0.5,0);
    const gizmo=new TransformControls(persp, renderer.domElement); gizmo.setSize(0.9); const gizmoHelper=(gizmo as any).getHelper ? (gizmo as any).getHelper() : (gizmo as any); scene.add(gizmoHelper);
    let dragging=false; let interacting=false; let needsRender=true; let disposed=false; let raf=0; let frames=0; let lastFps=performance.now();
    const mark=()=>{ needsRender=true; };
    orbit.addEventListener("start",()=>{ interacting=true; }); orbit.addEventListener("end",()=>{ interacting=false; needsRender=true; }); orbit.addEventListener("change",mark);
    gizmo.addEventListener("dragging-changed",(e:any)=>{ dragging=e.value; orbit.enabled=!dragging; if(!dragging){ // commit history: history already pushed? push snapshot from before drag stored below
        const before=(gizmo as any)._beforeDrag; if(before){ setHistory(h=>{ const n=[...h, before]; return n.length>100? n.slice(n.length-100):n; }); setRedoStack([]); } } else { (gizmo as any)._beforeDrag=cloneObjs(objectsRef.current); } needsRender=true; });
    gizmo.addEventListener("objectChange",()=>{
      const obj=gizmo.object as THREE.Object3D|null; if(!obj) return; const id=(obj.userData as any).sceneId as string; if(!id) return;
      setObjects(prev=> prev.map(o=> o.id===id? {...o, position:{x:obj.position.x,y:obj.position.y,z:obj.position.z}, rotation:{x:obj.rotation.x,y:obj.rotation.y,z:obj.rotation.z}, scale:{x:obj.scale.x,y:obj.scale.y,z:obj.scale.z}}:o)); needsRender=true;
    });
    const ray=new THREE.Raycaster(); const pointer=new THREE.Vector2();
    const onClick=(ev: MouseEvent)=>{
      if(dragging) return; if((ev.target as HTMLElement)!==renderer.domElement) return;
      const rect=renderer.domElement.getBoundingClientRect(); pointer.x=((ev.clientX-rect.left)/rect.width)*2-1; pointer.y=-((ev.clientY-rect.top)/rect.height)*2+1;
      const cam=camModeRef.current==="persp"? persp: ortho; ray.setFromCamera(pointer,cam);
      const meshes: THREE.Object3D[]=[]; mapRef.current.forEach(o=>{ o.traverse((c:any)=>{ if(c.isMesh) meshes.push(c); }); });
      const hits=ray.intersectObjects(meshes,false); if(!hits.length){ setSelected([]); return; }
      let node: THREE.Object3D|null=hits[0].object; let sid=""; while(node){ if((node.userData as any).sceneId){ sid=(node.userData as any).sceneId; break; } node=node.parent; }
      if(!sid) return; const obj=objectsRef.current.find(o=>o.id===sid); if(!obj||obj.locked) { if(obj?.locked) setSelected([sid]); return; }
      if(ev.shiftKey||ev.metaKey||ev.ctrlKey){ setSelected(prev=> prev.includes(sid)? prev.filter(x=>x!==sid): [...prev,sid]); } else setSelected([sid]);
    };
    renderer.domElement.addEventListener("click",onClick);
    const resize=()=>{ const w=container.clientWidth||600, h=container.clientHeight||400; renderer.setSize(w,h,false); persp.aspect=w/h; persp.updateProjectionMatrix(); const s=Math.max(w,h)/110; ortho.left=-s*(w/h); ortho.right=s*(w/h); ortho.top=s; ortho.bottom=-s; ortho.updateProjectionMatrix(); needsRender=true; };
    const ro=new ResizeObserver(resize); ro.observe(container); resize();
    const loop=()=>{ if(disposed) return; raf=requestAnimationFrame(loop); frames++; const now=performance.now(); if(now-lastFps>=1000){ setFps(frames); frames=0; lastFps=now; } if(needsRender||interacting||dragging){ orbit.update(); gizmo.updateMatrixWorld?.(); renderer.render(scene, camModeRef.current==="persp"? persp: ortho); setTriangles(renderer.info.render.triangles); setDrawCalls(renderer.info.render.calls); needsRender=false; } };
    loop();
    engineRef.current={ renderer, scene, persp, ortho, grid, axes, hemi, dir, orbit, gizmo, mark, resize };
    return ()=>{ disposed=true; cancelAnimationFrame(raf); ro.disconnect(); renderer.domElement.removeEventListener("click",onClick); orbit.dispose(); gizmo.dispose(); mapRef.current.forEach(o=>{ o.traverse((c:any)=>{ if(c.geometry) c.geometry.dispose(); }); }); matMapRef.current.forEach(m=> m.dispose()); renderer.dispose(); container.removeChild(renderer.domElement); engineRef.current=null; };
  },[]);

  // sync lights/bg/grid
  useEffect(()=>{ const e=engineRef.current; if(!e) return; e.hemi.intensity=lights.hemiIntensity; e.hemi.color.set(lights.hemiColor); e.dir.intensity=lights.dirIntensity; e.dir.color.set(lights.dirColor); e.dir.position.set(lights.dirPos.x,lights.dirPos.y,lights.dirPos.z); e.dir.castShadow=lights.shadows; e.renderer.shadowMap.enabled=lights.shadows; e.scene.background=new THREE.Color(bgPreset==="dark"?"#101214": bgPreset==="light"?"#e8eaee":"#1c2b2b"); e.grid.visible=showGrid; e.axes.visible=showAxes; e.mark(); },[lights,bgPreset,showGrid,showAxes]);
  // sync camera mode + gizmo mode/space/snap
  useEffect(()=>{ const e=engineRef.current; if(!e) return; const cam=camMode==="persp"? e.persp: e.ortho; const old=camMode==="persp"? e.ortho: e.persp; cam.position.copy(old.position); e.orbit.object=cam as any; e.orbit.update(); e.gizmo.camera=cam; e.gizmo.setMode(tool==="select"?"translate":tool); e.gizmo.setSpace(space); e.gizmo.setTranslationSnap(snapOn? snapStep: null); e.gizmo.setRotationSnap(snapOn? THREE.MathUtils.degToRad(15): null); e.gizmo.setScaleSnap(snapOn? 0.1: null); e.mark(); },[camMode,tool,space,snapOn,snapStep]);

  // reconcile objects -> three
  useEffect(()=>{
    const e=engineRef.current; if(!e) return;
    const seen=new Set<string>();
    // first pass create/update
    objects.forEach(o=>{
      seen.add(o.id);
      let obj3d=mapRef.current.get(o.id);
      if(!obj3d){ obj3d=buildObject3D(o, geoMapRef.current.get(o.id)); obj3d.userData.sceneId=o.id; mapRef.current.set(o.id,obj3d); }
      // geometry refresh for parametric: if type parametric, rebuild geometry when params change (store key)
      const key=JSON.stringify(o.params)+o.type; if((obj3d.userData as any)._geoKey!==key && o.type!=="group" && o.type!=="stairs" && o.type!=="roof"){
        const oldGeo=(obj3d as THREE.Mesh).geometry; const ng=buildGeometry(o, geoMapRef.current.get(o.id)); if(ng){ (obj3d as THREE.Mesh).geometry=ng; if(oldGeo && oldGeo!==ng) oldGeo.dispose(); }
      }
      if(o.type==="stairs"||o.type==="roof"){ const k=JSON.stringify(o.params); if((obj3d.userData as any)._geoKey!==k){ const parent=obj3d.parent; const fresh=buildObject3D(o); fresh.userData.sceneId=o.id; // replace children
          while(obj3d.children.length) obj3d.remove(obj3d.children[0]); fresh.children.forEach(c=> obj3d!.add(c)); } }
      (obj3d.userData as any)._geoKey=key;
      obj3d.position.set(o.position.x,o.position.y,o.position.z); obj3d.rotation.set(o.rotation.x,o.rotation.y,o.rotation.z); obj3d.scale.set(o.scale.x,o.scale.y,o.scale.z); obj3d.visible=o.visible;
      // material
      let mat=matMapRef.current.get(o.id) as THREE.MeshStandardMaterial|undefined; if(!mat){ mat=new THREE.MeshStandardMaterial(); matMapRef.current.set(o.id,mat); }
      mat.color.set(o.material.color); mat.roughness=o.material.roughness; mat.metalness=o.material.metalness; mat.opacity=o.material.opacity; mat.transparent=o.material.opacity<1; mat.wireframe=o.material.wireframe; mat.needsUpdate=true;
      obj3d.traverse((c:any)=>{ if(c.isMesh){ c.material=mat; c.castShadow=true; c.receiveShadow=true; } });
      // parenting
      const desiredParent=o.parentId? mapRef.current.get(o.parentId): null; const parent=obj3d.parent;
      if(desiredParent && parent!==desiredParent){ desiredParent.add(obj3d); }
      else if(!desiredParent && parent && parent!==e.scene){ e.scene.add(obj3d); }
      else if(!parent){ e.scene.add(obj3d); }
      if(parent===e.scene && !desiredParent){ /* keep */ }
    });
    // remove deleted
    Array.from(mapRef.current.keys()).forEach(id=>{ if(!seen.has(id)){ const o=mapRef.current.get(id)!; if(o.parent) o.parent.remove(o); o.traverse((c:any)=>{ if(c.geometry && !geoMapRef.current.has(id)) c.geometry.dispose(); }); mapRef.current.delete(id); const m=matMapRef.current.get(id); if(m) m.dispose(); matMapRef.current.delete(id); } });
    // selection highlight + gizmo attach
    helperMapRef.current.forEach(h=>{ if(h.parent) h.parent.remove(h); }); helperMapRef.current.clear();
    selected.forEach(id=>{ const o3d=mapRef.current.get(id); if(o3d && o3d.visible){ const h=new THREE.BoxHelper(o3d, new THREE.Color("#00f5a0")); e.scene.add(h); helperMapRef.current.set(id,h as any); } });
    const selObj=selected.length===1? mapRef.current.get(selected[0]): undefined;
    if(selObj && !objects.find(o=>o.id===selected[0])?.locked && tool!=="select"){ e.gizmo.attach(selObj as any); }
    else if(selObj && tool==="select"){ e.gizmo.detach(); }
    else if(selected.length!==1){ e.gizmo.detach(); }
    e.mark();
  },[objects,selected,tool]);

  const frameObjects=(list: SceneObj[])=>{ const e=engineRef.current; if(!e||!list.length) return; const box=new THREE.Box3(); list.forEach(o=>{ const m=mapRef.current.get(o.id); if(m) box.expandByObject(m); }); if(box.isEmpty()) return; const center=box.getCenter(new THREE.Vector3()); const size=box.getSize(new THREE.Vector3()); const dist=Math.max(size.length()*1.4,4); const cam=camModeRef.current==="persp"? e.persp: e.ortho; const dir=new THREE.Vector3(1,1,1).normalize(); // keep current view direction if possible
    const cur=cam.position.clone().sub(e.orbit.target).normalize(); if(cur.lengthSq()>0) dir.copy(cur);
    cam.position.copy(center).addScaledVector(dir,dist); e.orbit.target.copy(center); e.orbit.update(); e.mark(); };
  const setCameraPreset=(preset:string)=>{ const e=engineRef.current; if(!e) return; const cam=camModeRef.current==="persp"? e.persp: e.ortho; const center= selectedObjs.length? new THREE.Vector3(0,0.5,0): new THREE.Vector3(0,0.5,0); if(selectedObjs.length){ const b=new THREE.Box3(); selectedObjs.forEach(o=>{ const m=mapRef.current.get(o.id); if(m) b.expandByObject(m); }); if(!b.isEmpty()) b.getCenter(center); }
    const off= preset==="top"? new THREE.Vector3(0,9,0.01): preset==="front"? new THREE.Vector3(0,1,9): preset==="right"? new THREE.Vector3(9,1,0): new THREE.Vector3(6,6,6);
    cam.position.copy(center).add(off); e.orbit.target.copy(center); e.orbit.update(); e.mark(); };

  const addObject=(type: ObjType)=>{ const count=objectsRef.current.filter(o=>o.type===type).length+1; const obj=newPrimitive(type,count); obj.position.x=(Math.random()-0.5)*1.2; obj.position.z=(Math.random()-0.5)*1.2; applyObjects([...objectsRef.current,obj]); setSelected([obj.id]); showToast(`${typeLabel(type)} added — use the Move tool or the Inspector to place it.`); };
  const duplicateSelected=()=>{ if(!selected.length) return; const copies: SceneObj[]=[]; selected.forEach(id=>{ const o=objectsRef.current.find(x=>x.id===id); if(o){ const c={...cloneObjs([o])[0], id:uid(), name:o.name+" copy", position:{...o.position, x:o.position.x+0.4}, parentId:null}; copies.push(c); } }); if(copies.length){ applyObjects([...objectsRef.current,...copies]); setSelected(copies.map(c=>c.id)); showToast("Duplicated."); } };
  const deleteSelected=()=>{ if(!selected.length) return; const ids=new Set(selected); applyObjects(objectsRef.current.filter(o=> !ids.has(o.id) && !ids.has(o.parentId||""))); setSelected([]); showToast("Deleted."); };
  const undo=()=>{ setHistory(h=>{ if(!h.length) return h; const prev=h[h.length-1]; setRedoStack(r=>[...r, cloneObjs(objectsRef.current)]); setObjects(prev); return h.slice(0,-1); }); };
  const redo=()=>{ setRedoStack(r=>{ if(!r.length) return r; const next=r[r.length-1]; setHistory(h=>[...h, cloneObjs(objectsRef.current)]); setObjects(next); return r.slice(0,-1); }); };
  const groupSelected=()=>{ if(selected.length<2){ showToast("Select at least 2 objects to group."); return; } const gid=uid(); const g: SceneObj={ id:gid, name:"Group "+(objects.filter(o=>o.type==="group").length+1), type:"group", position:{x:0,y:0,z:0}, rotation:{x:0,y:0,z:0}, scale:{x:1,y:1,z:1}, material:defaultMat(), visible:true, locked:false, parentId:null, params:{} }; const next=objectsRef.current.map(o=> selected.includes(o.id)? {...o, parentId:gid}:o); applyObjects([...next,g]); setSelected([gid]); showToast("Grouped."); };
  const ungroupSelected=()=>{ const gid=selected[0]; if(!gid) return; const g=objectsRef.current.find(o=>o.id===gid); if(!g||g.type!=="group"){ showToast("Select a group to ungroup."); return; } const next=objectsRef.current.filter(o=>o.id!==gid).map(o=> o.parentId===gid? {...o, parentId:null}:o); applyObjects(next); setSelected(next.filter(o=>o.parentId===null).map(o=>o.id).slice(0,1)); };
  const copySel=()=>{ if(!selected.length) return; setClipboard(cloneObjs(selectedObjs)); showToast("Copied."); };
  const pasteSel=()=>{ if(!clipboard.length) return; const copies=clipboard.map(o=> ({...cloneObjs([o])[0], id:uid(), name:o.name+" copy", position:{...o.position, x:o.position.x+0.5}, parentId:null})); applyObjects([...objectsRef.current,...copies]); setSelected(copies.map(c=>c.id)); };
  const clearScene=()=>{ applyObjects([]); setSelected([]); setConfirmClear(false); showToast("Scene cleared."); };
  const updatePrimary=(patch: Partial<SceneObj>)=>{ if(!primary) return; setObjects(prev=> prev.map(o=> o.id===primary.id? {...o, ...patch}:o)); };
  const updatePrimaryField=(field:"position"|"rotation"|"scale", axis:"x"|"y"|"z", val:number)=>{ if(!primary) return; setObjects(prev=> prev.map(o=> o.id===primary.id? {...o, [field]:{...o[field], [axis]:val}}:o)); };
  const updatePrimaryMat=(patch: Partial<MatState>)=>{ if(!primary) return; setObjects(prev=> prev.map(o=> o.id===primary.id? {...o, material:{...o.material,...patch}}:o)); };
  const updatePrimaryParam=(k:string, v:number)=>{ if(!primary) return; setObjects(prev=> prev.map(o=> o.id===primary.id? {...o, params:{...o.params,[k]:v}}:o)); };
  const commitHistory=()=>{ pushHistory(objectsRef.current); };

  // keyboard
  useEffect(()=>{
    const onKey=(e: KeyboardEvent)=>{ const t=e.target as HTMLElement; if(t.tagName==="INPUT"||t.tagName==="TEXTAREA"||t.tagName==="SELECT"||t.isContentEditable) return; if(hash!=="#/studio" && !hash.startsWith("#/studio")) return;
      const mod=e.ctrlKey||e.metaKey;
      if(mod && e.key.toLowerCase()==="z" && !e.shiftKey){ e.preventDefault(); undo(); return; }
      if(mod && (e.key.toLowerCase()==="y" || (e.shiftKey && e.key.toLowerCase()==="z"))){ e.preventDefault(); redo(); return; }
      if(mod && e.key.toLowerCase()==="d"){ e.preventDefault(); duplicateSelected(); return; }
      if(mod && e.key.toLowerCase()==="c"){ copySel(); return; }
      if(mod && e.key.toLowerCase()==="v"){ e.preventDefault(); pasteSel(); return; }
      if(e.key==="Delete"||e.key==="Backspace"){ deleteSelected(); return; }
      if(e.key.toLowerCase()==="w") setTool("translate"); if(e.key.toLowerCase()==="e") setTool("rotate"); if(e.key.toLowerCase()==="r") setTool("scale");
      if(e.key.toLowerCase()==="f") frameObjects(selectedObjs.length? selectedObjs: objectsRef.current);
      if(e.key==="?") setShowShortcuts(true);
      if(e.key==="Escape") setSelected([]);
    }; window.addEventListener("keydown",onKey); return ()=> window.removeEventListener("keydown",onKey);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  },[hash, objects, selected]);

  const saveProjectNow=async()=>{
    setBusy(true); setSaveState("Saving…");
    try{ if(currentProjectId){ await api("records.replace", { collection:"toolsx3d-projects", id:currentProjectId, value:{ name:projectName, schemaVersion:SCHEMA_VERSION, objects, updatedAt:new Date().toISOString() } }); }
      else { const created:any= await api("records.create", { collection:"toolsx3d-projects", value:{ name:projectName, schemaVersion:SCHEMA_VERSION, objects, updatedAt:new Date().toISOString() }, idempotency_key: "toolsx-"+Date.now()+"-"+uid() }); setCurrentProjectId(created.id); }
      setSaveState("Saved"); showToast("Project saved."); loadProjects();
    } catch(e:any){ setSaveState("Save unavailable"); showToast("Could not save. Export a backup from the Export menu."); }
    setBusy(false);
  };
  const openProject=(p: ProjectRecord)=>{ skipSaveRef.current=true; setCurrentProjectId(p.id); setProjectName(p.value.name); setObjects(migrateProject(p.value)); setSelected([]); setSaveState("Saved"); window.location.hash="#/studio"; showToast(`Opened “${p.value.name}”.`); };
  const createProject=async(name:string)=>{ setBusy(true); try{ const created:any= await api("records.create", { collection:"toolsx3d-projects", value:{ name, schemaVersion:SCHEMA_VERSION, objects:[], updatedAt:new Date().toISOString() }, idempotency_key:"toolsx-new-"+Date.now()+"-"+uid() }); setProjectsLoading(false); loadProjects(); showToast("Project created."); return created; } catch(e:any){ showToast("Could not create project — save service unavailable."); } setBusy(false); };
  const duplicateProject=async(p: ProjectRecord)=>{ try{ await api("records.create", { collection:"toolsx3d-projects", value:{ name:p.value.name+" copy", schemaVersion:SCHEMA_VERSION, objects:p.value.objects, updatedAt:new Date().toISOString() }, idempotency_key:"toolsx-dup-"+p.id+"-"+Date.now() }); loadProjects(); showToast("Project duplicated."); } catch{ showToast("Could not duplicate project."); } };
  const deleteProject=async(p: ProjectRecord)=>{ try{ await api("records.delete", { collection:"toolsx3d-projects", id:p.id }); if(currentProjectId===p.id){ setCurrentProjectId(null); } loadProjects(); showToast("Project deleted."); } catch{ showToast("Could not delete project."); } };
  const renameProject=async(p: ProjectRecord, name:string)=>{ try{ await api("records.replace", { collection:"toolsx3d-projects", id:p.id, value:{...p.value, name} }); loadProjects(); showToast("Project renamed."); } catch{ showToast("Could not rename project."); } };

  const exportProjectJSON=()=>{ const data={ schemaVersion:SCHEMA_VERSION, name:projectName, objects }; downloadBlob(new Blob([JSON.stringify(data,null,2)],{type:"application/json"}), projectName.replace(/[^a-z0-9]+/gi,"-").toLowerCase()+".toolsx3d.json"); showToast("Project JSON downloaded."); };
  const importProjectJSON=async(file: File)=>{
    try{ const text=await file.text(); const data=JSON.parse(text); if(!data || typeof data!=="object") throw new Error("Invalid file"); const objs=migrateProject(data); if(!Array.isArray(data.objects) && !Array.isArray(data)) throw new Error("No objects found"); skipSaveRef.current=true; setObjects(objs); setProjectName(typeof data.name==="string"? data.name: "Imported project"); setCurrentProjectId(null); setSaveState("Not saved yet"); showToast("Project file imported."); window.location.hash="#/studio"; }
    catch{ showToast("That project file could not be read. Check it is a .toolsx3d.json export."); }
  };
  const doExport=async()=>{
    const scopeObjs= exportScope==="selected" && selected.length? selectedObjs: objects;
    if(exportFormat==="json"){ exportProjectJSON(); setShowExport(false); return; }
    if(exportFormat==="png"){ const e=engineRef.current; if(e){ e.mark(); setTimeout(()=>{ try{ const url=e.renderer.domElement.toDataURL("image/png"); const a=document.createElement("a"); a.href=url; a.download="toolsx-3d-screenshot.png"; a.click(); showToast("PNG screenshot downloaded."); } catch{ showToast("PNG export failed."); } },120); } setShowExport(false); return; }
    if(!scopeObjs.length){ showToast("Add an object before exporting."); return; }
    try{
      const expScene=new THREE.Scene(); scopeObjs.forEach(o=>{ const m=mapRef.current.get(o.id); if(m && o.parentId===null) expScene.add(m.clone(true)); else if(m && exportScope==="selected") expScene.add(m.clone(true)); });
      if(exportFormat==="glb"||exportFormat==="gltf"){ const ex=new GLTFExporter(); ex.parse(expScene, (res:any)=>{ if(res instanceof ArrayBuffer) downloadBlob(new Blob([res],{type:"model/gltf-binary"}),"toolsx-3d.glb"); else downloadBlob(new Blob([JSON.stringify(res)],{type:"model/gltf+json"}),"toolsx-3d.gltf"); showToast("GLTF export downloaded."); }, (err:any)=>{ showToast("Export failed: "+(err?.message||"unknown")); }, { binary: exportFormat==="glb" }); }
      if(exportFormat==="obj"){ const ex=new OBJExporter(); const txt=ex.parse(expScene); downloadBlob(new Blob([txt],{type:"text/plain"}),"toolsx-3d.obj"); showToast("OBJ downloaded."); }
      if(exportFormat==="stl"){ const ex=new STLExporter(); const out=ex.parse(expScene,{binary:true}); const blob= out instanceof DataView? new Blob([out.buffer],{type:"model/stl"}): new Blob([out],{type:"model/stl"}); downloadBlob(blob,"toolsx-3d.stl"); showToast("STL downloaded."); }
    } catch(e:any){ showToast("Export failed: "+(e.message||"unknown")); }
    setShowExport(false);
  };
  const importFile=async(file: File)=>{
    if(file.size>50*1024*1024){ showToast("File is over the 50 MB limit."); return; }
    setImportStatus(`Reading ${file.name}…`);
    try{
      const name=file.name.toLowerCase();
      if(name.endsWith(".toolsx3d.json")||name.endsWith(".json")){ await importProjectJSON(file); setImportStatus(""); return; }
      const buf=await file.arrayBuffer();
      let loaded: THREE.Object3D|null=null;
      if(name.endsWith(".glb")||name.endsWith(".gltf")){ const loader=new GLTFLoader(); const gltf=await new Promise<any>((res,rej)=> loader.parse(buf, "", res, rej)); loaded=gltf.scene; }
      else if(name.endsWith(".obj")){ const txt=new TextDecoder().decode(buf); loaded=new OBJLoader().parse(txt); }
      else if(name.endsWith(".stl")){ const geo=new STLLoader().parse(buf); const mesh=new THREE.Mesh(geo); loaded=new THREE.Group(); loaded.add(mesh); }
      else throw new Error("Unsupported format");
      if(!loaded) throw new Error("Empty file");
      // normalize
      const box=new THREE.Box3().setFromObject(loaded); if(box.isEmpty()) throw new Error("No geometry found");
      const center=box.getCenter(new THREE.Vector3()); const size=box.getSize(new THREE.Vector3()); const maxDim=Math.max(size.x,size.y,size.z)||1; const scale=3/maxDim; loaded.position.sub(center); loaded.scale.setScalar(scale);
      const newObjs: SceneObj[]=[]; const meshes: THREE.Mesh[]=[]; loaded.traverse((c:any)=>{ if(c.isMesh) meshes.push(c); });
      if(!meshes.length) throw new Error("No meshes found");
      meshes.forEach((m,i)=>{ const id=uid(); const world=m.getWorldPosition(new THREE.Vector3()); const geo=m.geometry.clone(); geoMapRef.current.set(id, geo); const obj: SceneObj={ id, name: file.name.replace(/\.[^.]+$/,"")+" "+(i+1), type:"imported", position:{x:world.x,y:Math.max(0.2,world.y),z:world.z}, rotation:{x:0,y:0,z:0}, scale:{x:1,y:1,z:1}, material: defaultMat("#8fb8c8"), visible:true, locked:false, parentId:null, params:{} }; newObjs.push(obj); });
      applyObjects([...objectsRef.current,...newObjs]); setSelected(newObjs.map(o=>o.id)); setImportStatus(""); showToast(`Imported ${newObjs.length} mesh${newObjs.length>1?"es":""} from ${file.name}.`);
    } catch(e:any){ setImportStatus(""); showToast("Import failed: "+(e.message||"That file could not be read.")); }
  };
  const loadTemplate=(kind:string)=>{ skipSaveRef.current=true; setObjects(templateObjects(kind)); setProjectName(kind==="Empty"?"Untitled Project":kind+" — Template"); setCurrentProjectId(null); setSaveState("Not saved yet"); setSelected([]); window.location.hash="#/studio"; showToast(`${kind} template loaded.`); };
  const selBox=useMemo(()=>{ if(!selectedObjs.length) return null; let minX=Infinity,minY=Infinity,minZ=Infinity,maxX=-Infinity,maxY=-Infinity,maxZ=-Infinity; selectedObjs.forEach(o=>{ const m=mapRef.current.get(o.id); if(m){ const b=new THREE.Box3().setFromObject(m); minX=Math.min(minX,b.min.x); minY=Math.min(minY,b.min.y); minZ=Math.min(minZ,b.min.z); maxX=Math.max(maxX,b.max.x); maxY=Math.max(maxY,b.max.y); maxZ=Math.max(maxZ,b.max.z); } }); if(!isFinite(minX)) return null; const w=maxX-minX,d=maxZ-minZ,h=maxY-minY; return { w,d,h, area:w*d, vol:w*d*h }; },[selectedObjs, objects]);

  const route=hash.replace(/^#\/?/,"")||"studio";
  const nav=(h:string)=>{ window.location.hash=h; };
  const go=(h:string)=> <a href={h} onClick={(e)=>{ e.preventDefault(); nav(h); }} className={`navlink ${hash===h?"active":""}`}>{h}</a>;

  const addButtons=(
    <div style={{display:"flex",flexWrap:"wrap",gap:6}}>
      <button className="btn" onClick={()=>addObject("box")}><Box size={16}/> Box</button>
      <button className="btn" onClick={()=>addObject("sphere")}><Circle size={16}/> Sphere</button>
      <button className="btn" onClick={()=>addObject("cylinder")}><Cylinder size={16}/> Cylinder</button>
      <button className="btn" onClick={()=>addObject("cone")}><Cone size={16}/> Cone</button>
      <button className="btn" onClick={()=>addObject("torus")}><Circle size={16}/> Torus</button>
      <button className="btn" onClick={()=>addObject("plane")}><Square size={16}/> Plane</button>
      <button className="btn" onClick={()=>addObject("wall")}><Layers size={16}/> Wall</button>
      <button className="btn" onClick={()=>addObject("floor")}><Square size={16}/> Floor</button>
      <button className="btn" onClick={()=>addObject("door")}><DoorOpen size={16}/> Door</button>
      <button className="btn" onClick={()=>addObject("window")}><Square size={16}/> Window</button>
      <button className="btn" onClick={()=>addObject("column")}><Cylinder size={16}/> Column</button>
      <button className="btn" onClick={()=>addObject("stairs")}><Layers size={16}/> Stairs</button>
      <button className="btn" onClick={()=>addObject("roof")}><Triangle size={16}/> Roof</button>
    </div>
  );
  const outliner=(
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}><strong>Outliner</strong><span className="chip">{objects.length} objects</span></div>
      {objects.length===0? <div style={{padding:"18px 0",color:"var(--muted)",fontSize:13}}>No objects yet. Add a box to start. Click an object in the viewport or here to select it.</div> : objects.map(o=>(
        <div key={o.id} style={{display:"flex",alignItems:"center",gap:6,padding:"7px 8px",marginTop:6,borderRadius:8,background: selected.includes(o.id)? "var(--surface3)":"transparent", border: selected.includes(o.id)? "1px solid var(--accent)":"1px solid transparent", marginLeft: o.parentId? 16:0}}>
          <button className="iconbtn" style={{width:32,height:32}} aria-label={o.visible?"Hide":"Show"} onClick={()=> setObjects(prev=> prev.map(x=> x.id===o.id? {...x, visible:!x.visible}:x))}>{o.visible? <Eye size={15}/> : <EyeOff size={15}/>}</button>
          <button style={{flex:1,textAlign:"left",background:"transparent",border:"none",color:"var(--text)",minWidth:0,overflowWrap:"anywhere"}} onClick={()=> setSelected([o.id])} onDoubleClick={()=>{ setRenameId(o.id); setRenameVal(o.name); }}>
            {renameId===o.id? <input className="field" value={renameVal} autoFocus onChange={e=>setRenameVal(e.target.value)} onBlur={()=>{ if(renameVal.trim()){ const prev=objectsRef.current; pushHistory(prev); setObjects(prev2=> prev2.map(x=> x.id===o.id? {...x,name:renameVal.trim()}:x)); } setRenameId(null); }} onKeyDown={e=>{ if(e.key==="Enter") (e.target as HTMLInputElement).blur(); }} /> : <span style={{fontSize:13,fontWeight:650}}>{o.name} <span style={{color:"var(--muted)",fontWeight:400}}>· {typeLabel(o.type)}</span></span>}
          </button>
          <button className="iconbtn" style={{width:32,height:32}} aria-label="Lock" onClick={()=> setObjects(prev=> prev.map(x=> x.id===o.id? {...x, locked:!x.locked}:x))}>{o.locked? <Lock size={15}/> : <Unlock size={15}/>}</button>
        </div>
      ))}
      <p style={{fontSize:12,color:"var(--muted)"}}>Double-click a name to rename. Hide, lock and selection all work here and in the viewport.</p>
    </div>
  );
  const inspector=(
    <div>
      <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>{(["transform","material","lights","arch"] as const).map(t=> <button key={t} className="btn" style={inspectorTab===t? {background:"var(--accent)",color:"var(--accent-ink)"}:undefined} onClick={()=>setInspectorTab(t)}>{t==="arch"?"Architecture": t.charAt(0).toUpperCase()+t.slice(1)}</button>)}</div>
      {inspectorTab==="transform" && (primary? <div>
        <label className="lbl">Selected — {primary.name}</label>
        <p style={{fontSize:12,color:"var(--muted)"}}>{typeLabel(primary.type)} · {primary.locked? "Locked — unlock to move it.":"Drag the gizmo or type numbers."}</p>
        {(["position","rotation","scale"] as const).map(field=> <div key={field}><label className="lbl">{field} {field==="rotation"?"(radians)":"(metres)"}</label><div className="numrow">{(["x","y","z"] as const).map(ax=> <label key={ax}>{ax.toUpperCase()}<input className="field" type="number" step={field==="rotation"?0.1:0.1} value={Number(primary[field][ax].toFixed(3))} disabled={primary.locked} onChange={e=> updatePrimaryField(field,ax,Number(e.target.value))} onBlur={commitHistory} /></label>)}</div></div>)}
        {selBox && <div className="card" style={{marginTop:14}}><strong>Selection size</strong><p style={{fontSize:13,margin:"6px 0"}}>W {selBox.w.toFixed(2)} m · D {selBox.d.toFixed(2)} m · H {selBox.h.toFixed(2)} m<br/>Floor area {selBox.area.toFixed(2)} m² · Volume {selBox.vol.toFixed(2)} m³</p></div>}
      </div> : <p style={{fontSize:13,color:"var(--muted)",marginTop:12}}>Select an object to edit its transform.</p>)}
      {inspectorTab==="material" && (primary? <div>
        <label className="lbl">Colour</label><input type="color" value={primary.material.color} disabled={primary.locked} onChange={e=> updatePrimaryMat({color:e.target.value})} onBlur={commitHistory} />
        <label className="lbl">Roughness {primary.material.roughness.toFixed(2)}</label><input type="range" min={0} max={1} step={0.01} value={primary.material.roughness} onChange={e=> updatePrimaryMat({roughness:Number(e.target.value)})} onBlur={commitHistory} />
        <label className="lbl">Metalness {primary.material.metalness.toFixed(2)}</label><input type="range" min={0} max={1} step={0.01} value={primary.material.metalness} onChange={e=> updatePrimaryMat({metalness:Number(e.target.value)})} onBlur={commitHistory} />
        <label className="lbl">Opacity {primary.material.opacity.toFixed(2)}</label><input type="range" min={0.1} max={1} step={0.01} value={primary.material.opacity} onChange={e=> updatePrimaryMat({opacity:Number(e.target.value)})} onBlur={commitHistory} />
        <label style={{display:"flex",gap:8,alignItems:"center",marginTop:12,fontSize:13}}><input type="checkbox" checked={primary.material.wireframe} onChange={e=> updatePrimaryMat({wireframe:e.target.checked})} /> Wireframe</label>
        <label className="lbl">Material presets</label>
        <div style={{display:"flex",flexWrap:"wrap",gap:6}}>
          <button className="btn" onClick={()=>{ updatePrimaryMat({color:"#c9c9c9",roughness:0.9,metalness:0,opacity:1,wireframe:false}); commitHistory(); }}>Matte</button>
          <button className="btn" onClick={()=>{ updatePrimaryMat({color:"#b8bec6",roughness:0.25,metalness:0.9,opacity:1,wireframe:false}); commitHistory(); }}>Metal</button>
          <button className="btn" onClick={()=>{ updatePrimaryMat({color:"#bfe8f2",roughness:0.05,metalness:0,opacity:0.35,wireframe:false}); commitHistory(); }}>Glass</button>
          <button className="btn" onClick={()=>{ updatePrimaryMat({color:"#a67c4d",roughness:0.7,metalness:0,opacity:1,wireframe:false}); commitHistory(); }}>Wood</button>
          <button className="btn" onClick={()=>{ updatePrimaryMat({color:"#9aa0a3",roughness:0.95,metalness:0,opacity:1,wireframe:false}); commitHistory(); }}>Concrete</button>
        </div>
      </div> : <p style={{fontSize:13,color:"var(--muted)",marginTop:12}}>Select an object to edit its material.</p>)}
      {inspectorTab==="lights" && <div>
        <label className="lbl">Hemisphere intensity {lights.hemiIntensity.toFixed(2)}</label><input type="range" min={0} max={2} step={0.05} value={lights.hemiIntensity} onChange={e=> setLights(s=>({...s,hemiIntensity:Number(e.target.value)}))} />
        <label className="lbl">Hemisphere colour</label><input type="color" value={lights.hemiColor} onChange={e=> setLights(s=>({...s,hemiColor:e.target.value}))} />
        <label className="lbl">Directional intensity {lights.dirIntensity.toFixed(2)}</label><input type="range" min={0} max={3} step={0.05} value={lights.dirIntensity} onChange={e=> setLights(s=>({...s,dirIntensity:Number(e.target.value)}))} />
        <label className="lbl">Directional colour</label><input type="color" value={lights.dirColor} onChange={e=> setLights(s=>({...s,dirColor:e.target.value}))} />
        <label className="lbl">Directional position</label><div className="numrow">{(["x","y","z"] as const).map(ax=> <label key={ax}>{ax.toUpperCase()}<input className="field" type="number" value={lights.dirPos[ax]} onChange={e=> setLights(s=>({...s,dirPos:{...s.dirPos,[ax]:Number(e.target.value)}}))} /></label>)}</div>
        <label style={{display:"flex",gap:8,alignItems:"center",marginTop:12,fontSize:13}}><input type="checkbox" checked={lights.shadows} onChange={e=> setLights(s=>({...s,shadows:e.target.checked}))} /> Shadows</label>
      </div>}
      {inspectorTab==="arch" && (primary && ["wall","floor","door","window","column","stairs","roof"].includes(primary.type)? <div>
        <p style={{fontSize:13}}>Editing <strong>{primary.name}</strong> — change a number and the shape rebuilds.</p>
        {Object.keys(primary.params).map(k=> <div key={k}><label className="lbl">{k} {k==="steps"||k==="style"?"": "(m)"}</label><input className="field" type="number" step={k==="steps"||k==="style"?1:0.1} min={k==="steps"?1:0.05} value={primary.params[k]} onChange={e=> updatePrimaryParam(k,Number(e.target.value))} onBlur={commitHistory} /></div>)}
        {primary.type==="roof" && <p style={{fontSize:12,color:"var(--muted)"}}>Style 0 = flat, 1 = gable.</p>}
        {primary.type==="wall" && selBox && <p style={{fontSize:13}}>Wall area ≈ {( (primary.params.length||0)*(primary.params.height||0)).toFixed(2)} m²</p>}
      </div> : <div><p style={{fontSize:13,color:"var(--muted)",marginTop:12}}>Select a wall, floor, door, window, column, stairs or roof to edit its dimensions.</p><div style={{display:"flex",flexWrap:"wrap",gap:6,marginTop:8}}><button className="btn" onClick={()=>addObject("wall")}>Add wall</button><button className="btn" onClick={()=>addObject("floor")}>Add floor</button><button className="btn" onClick={()=>addObject("stairs")}>Add stairs</button></div></div>)}
    </div>
  );

  const studio=(
    <div style={{display:"flex",flexDirection:"column",minHeight:0,flex:1}}>
      <div style={{padding:"12px 12px 2px",background:"var(--surface)"}}><h1 style={{fontSize:"clamp(22px,3vw,28px)",lineHeight:1.1,margin:"0 0 2px"}}>Studio — build in 3D</h1><p style={{margin:"0 0 8px",fontSize:13,color:"var(--muted)"}}>Add a shape, select it in the viewport, move it with the gizmo, then export a real file.</p></div>
      <div style={{display:"flex",gap:6,flexWrap:"wrap",padding:"10px 12px",borderBottom:"1px solid var(--border)",background:"var(--surface)",alignItems:"center"}}>
        <button className={`iconbtn ${tool==="select"?"active":""}`} aria-label="Select tool" onClick={()=>setTool("select")}><MousePointer2 size={18}/></button>
        <button className={`iconbtn ${tool==="translate"?"active":""}`} aria-label="Move tool" onClick={()=>setTool("translate")}><Move size={18}/></button>
        <button className={`iconbtn ${tool==="rotate"?"active":""}`} aria-label="Rotate tool" onClick={()=>setTool("rotate")}><RotateCw size={18}/></button>
        <button className={`iconbtn ${tool==="scale"?"active":""}`} aria-label="Scale tool" onClick={()=>setTool("scale")}><Maximize2 size={18}/></button>
        <span style={{fontSize:12,color:"var(--muted)"}}>W Move · E Rotate · R Scale · F Frame · Del Delete · ? Shortcuts</span>
        <label style={{display:"flex",gap:6,alignItems:"center",fontSize:13}}><input type="checkbox" checked={snapOn} onChange={e=>setSnapOn(e.target.checked)} /> Snap</label>
        <select className="field" style={{width:110}} value={snapStep} onChange={e=>setSnapStep(Number(e.target.value))} aria-label="Grid snap step"><option value={0.1}>0.1 m</option><option value={0.5}>0.5 m</option><option value={1}>1 m</option></select>
        <button className="btn" onClick={()=>setSpace(space==="local"?"world":"local")}>{space==="local"?"Local":"World"}</button>
        <button className="btn" onClick={()=>setCamMode(camMode==="persp"?"ortho":"persp")}>{camMode==="persp"?"Perspective":"Orthographic"}</button>
        <button className="btn" onClick={()=>setCameraPreset("top")}>Top / Plan</button>
        <button className="btn" onClick={()=>setCameraPreset("front")}>Front</button>
        <button className="btn" onClick={()=>setCameraPreset("right")}>Right</button>
        <button className="btn" onClick={()=>setCameraPreset("iso")}>Iso</button>
        <button className="btn" onClick={()=>frameObjects(selectedObjs.length? selectedObjs: objectsRef.current)}>Frame (F)</button>
        <label style={{display:"flex",gap:6,alignItems:"center",fontSize:13}}><input type="checkbox" checked={showGrid} onChange={e=>setShowGrid(e.target.checked)} /> Grid</label>
        <label style={{display:"flex",gap:6,alignItems:"center",fontSize:13}}><input type="checkbox" checked={showAxes} onChange={e=>setShowAxes(e.target.checked)} /> Axes</label>
        <select className="field" style={{width:130}} value={bgPreset} onChange={e=>setBgPreset(e.target.value as any)} aria-label="Background"><option value="dark">Dark background</option><option value="light">Light background</option><option value="studio">Studio background</option></select>
      </div>
      {!hintDismissed && <div style={{display:"flex",justifyContent:"space-between",gap:10,padding:"9px 12px",background:"var(--surface2)",fontSize:13}}><span><strong>First time?</strong> Add a box → drag the gizmo to move it → Export to download a GLB.</span><button className="btn" onClick={()=>setHintDismissed(true)}>Got it</button></div>}
      <div style={{display:"flex",flex:1,minHeight:0}}>
        <aside className="panel desktop-only" style={{width:280,borderRight:"1px solid var(--border)",padding:14,background:"var(--surface)"}}><label className="lbl" style={{marginTop:0}}>Add</label>{addButtons}<div style={{marginTop:16}}>{outliner}</div></aside>
        <div style={{flex:1,display:"flex",flexDirection:"column",minWidth:0,position:"relative"}}>
          <div ref={viewportRef} style={{flex:1,minHeight:420,background:"#101214",position:"relative",overflow:"hidden"}} onDragOver={e=>e.preventDefault()} onDrop={e=>{ e.preventDefault(); const f=e.dataTransfer.files?.[0]; if(f) importFile(f); }} />
          {webglError && <div style={{position:"absolute",inset:0,display:"flex",alignItems:"center",justifyContent:"center",background:"var(--surface)",padding:20,textAlign:"center"}}><div><AlertTriangle size={28}/><h3>WebGL not available</h3><p>{webglError}</p></div></div>}
          {(importStatus) && <div style={{position:"absolute",top:12,left:12,background:"var(--surface)",border:"1px solid var(--border)",padding:"8px 12px",borderRadius:8,fontSize:13}}>{importStatus}</div>}
          <div className="mobile-only" style={{display:"flex",gap:6,padding:"10px",overflowX:"auto",background:"var(--surface)",borderTop:"1px solid var(--border)"}}>
            <button className="btn" onClick={()=>setLeftOpen(true)}><Plus size={16}/> Add</button>
            <button className="btn" onClick={()=>setRightOpen(true)}>Inspector</button>
            <button className="btn" onClick={()=>setTool("select")}>Select</button>
            <button className="btn" onClick={()=>setTool("translate")}>Move</button>
            <button className="btn" onClick={()=>setTool("rotate")}>Rotate</button>
            <button className="btn" onClick={()=>setTool("scale")}>Scale</button>
            <button className="btn" onClick={undo} disabled={!history.length}>Undo</button>
          </div>
          <div style={{display:"flex",gap:14,flexWrap:"wrap",padding:"8px 12px",borderTop:"1px solid var(--border)",background:"var(--surface)",fontSize:12,color:"var(--muted)"}}>
            <span><strong style={{color:"var(--text)"}}>{fps} FPS</strong></span><span>{triangles.toLocaleString()} triangles</span><span>{drawCalls} draw calls</span><span>{selected.length} selected</span><span>Snap {snapOn? snapStep+" m":"off"} · Rotation 15°</span><span>Units: metres</span><span>{saveState}</span>
            <span style={{marginLeft:"auto"}}>Drag to orbit · Right-drag to pan · Scroll to zoom · Click to select</span>
          </div>
        </div>
        <aside className="panel desktop-only" style={{width:320,borderLeft:"1px solid var(--border)",padding:14,background:"var(--surface)"}}>{inspector}
          <div style={{marginTop:18,display:"flex",flexWrap:"wrap",gap:6}}>
            <button className="btn" onClick={duplicateSelected} disabled={!selected.length}><Copy size={15}/> Duplicate</button>
            <button className="btn danger" onClick={deleteSelected} disabled={!selected.length}><Trash2 size={15}/> Delete</button>
            <button className="btn" onClick={groupSelected} disabled={selected.length<2}>Group</button>
            <button className="btn" onClick={ungroupSelected}>Ungroup</button>
            <button className="btn" onClick={copySel} disabled={!selected.length}>Copy</button>
            <button className="btn" onClick={pasteSel} disabled={!clipboard.length}>Paste</button>
            <button className="btn" onClick={()=>setConfirmClear(true)}>Clear scene</button>
          </div>
        </aside>
      </div>
    </div>
  );

  const projectsScreen=(
    <main style={{maxWidth:980,margin:"0 auto",padding:"24px 16px"}}>
      <h1 style={{fontSize:"clamp(24px,4vw,34px)",margin:"4px 0 6px"}}>My Projects</h1>
      <p style={{color:"var(--muted)"}}>Projects are saved in this browser. Use Export to back them up.</p>
      <div style={{display:"flex",gap:8,flexWrap:"wrap",margin:"16px 0"}}>
        <button className="btn primary" onClick={async()=>{ const p=await createProject("Untitled Project "+(projects.length+1)); if(p){ openProject({id:p.id,value:p.value,created_at:p.created_at,updated_at:p.updated_at} as any); } }} disabled={busy}><FilePlus size={16}/> New project</button>
        <label className="btn" style={{cursor:"pointer"}}><Upload size={16}/> Import .toolsx3d.json<input type="file" accept=".json,.toolsx3d.json" style={{display:"none"}} onChange={e=>{ const f=e.target.files?.[0]; if(f) importProjectJSON(f); e.target.value=""; }} /></label>
        <button className="btn" onClick={loadProjects}>Refresh</button>
      </div>
      {projectsLoading && <p>Loading projects…</p>}{projectsError && <p role="alert" style={{color:"var(--danger)"}}>{projectsError}</p>}
      {!projectsLoading && !projectsError && projects.length===0 && <div className="card"><h3>No projects yet</h3><p style={{color:"var(--muted)"}}>Create a project, or open the Studio and save what you build.</p><button className="btn primary" onClick={()=>nav("#/studio")}>Open Studio</button></div>}
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(240px,1fr))",gap:12}}>
        {projects.map(p=> <article key={p.id} className="card"><h3 style={{margin:"0 0 4px",overflowWrap:"anywhere"}}>{p.value?.name||"Untitled"}</h3><p style={{color:"var(--muted)",fontSize:13,margin:"0 0 10px"}}>{(p.value?.objects||[]).length} objects · Updated {new Date(p.updated_at||p.value?.updatedAt||Date.now()).toLocaleString()}</p>
          <div style={{display:"flex",flexWrap:"wrap",gap:6}}><button className="btn primary" onClick={()=>openProject(p)}>Open</button><button className="btn" onClick={()=>{ const n=window.prompt("Rename project", p.value.name); if(n && n.trim()) renameProject(p,n.trim()); }}>Rename</button><button className="btn" onClick={()=>duplicateProject(p)}>Duplicate</button><button className="btn danger" onClick={()=>{ if(window.confirm(`Delete “${p.value.name}”? This cannot be undone.`)) deleteProject(p); }}>Delete</button></div></article>)}
      </div>
    </main>
  );
  const templatesScreen=(
    <main style={{maxWidth:980,margin:"0 auto",padding:"24px 16px"}}><h1 style={{fontSize:"clamp(24px,4vw,34px)"}}>Templates</h1><p style={{color:"var(--muted)"}}>Real scenes that load into the Studio. Every object stays editable.</p>
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(220px,1fr))",gap:12,marginTop:16}}>
        {["Empty","Room","House","Building","Table"].map(t=> <article key={t} className="card"><h3>{t}</h3><p style={{color:"var(--muted)",fontSize:13}}>{t==="Empty"?"Start from a clean grid.": t==="Room"?"Floor, two walls, door and window.": t==="House"?"Slab, four walls, gable roof and porch column.": t==="Building"?"Three stacked levels with a flat roof.":"Table top and four legs."}</p><p style={{fontSize:12,color:"var(--muted)"}}>{templateObjects(t).length} objects</p><button className="btn primary" onClick={()=>loadTemplate(t)}>Load {t}</button></article>)}
      </div></main>
  );
  const helpScreen=(
    <main style={{maxWidth:860,margin:"0 auto",padding:"24px 16px"}}><h1>Help</h1>
      <h2>Shortcuts</h2><table><thead><tr><th>Action</th><th>Shortcut</th></tr></thead><tbody><tr><td>Move / Rotate / Scale</td><td>W / E / R</td></tr><tr><td>Undo / Redo</td><td>Ctrl+Z / Ctrl+Shift+Z or Ctrl+Y</td></tr><tr><td>Duplicate</td><td>Ctrl+D</td></tr><tr><td>Copy / Paste</td><td>Ctrl+C / Ctrl+V</td></tr><tr><td>Delete</td><td>Delete</td></tr><tr><td>Frame selection / all</td><td>F</td></tr><tr><td>Shortcut list</td><td>?</td></tr></tbody></table>
      <h2>Formats</h2><p>Import: GLB, GLTF, OBJ, STL and .toolsx3d.json project files (max 50 MB). Export: GLB, GLTF, OBJ, STL, PNG screenshot and project JSON. Export applies to the whole scene or only the current selection.</p>
      <h2>Limits</h2><ul><li>Import files up to 50 MB.</li><li>Projects are stored in this browser. Export a backup for anything important.</li><li>History keeps the last 100 changes.</li></ul>
      <h2>FAQ</h2><h3>Why can’t I move an object?</h3><p>It may be locked. Select it in the Outliner and unlock it, or choose the Select tool first.</p><h3>How do I see a top-down plan?</h3><p>Use the Top / Plan button. That switches the camera to a top view. Use Orthographic for a true plan look.</p><h3>Do I need an account?</h3><p>No. There is no login. Projects live in this browser.</p>
    </main>
  );
  const legal=(title:string, body:React.ReactNode)=>(<main style={{maxWidth:860,margin:"0 auto",padding:"24px 16px"}}><h1>{title}</h1>{body}<p style={{marginTop:24}}><a href="#/studio">Back to Studio</a> · <a href="https://toolsx.in" target="_blank" rel="noopener">ToolsX.in</a></p></main>);

  return (
    <Boundary>
    <div className="shell" data-safe-area-inset-root data-theme={theme} style={{boxSizing:"border-box",paddingTop:"var(--safe-area-inset-top)",display:"flex",flexDirection:"column",minHeight:"100vh",overflowX:"clip"}}>
      <header className="topbar" data-safe-area-sticky-top style={{top:"var(--safe-area-inset-top)"}}>
        <a href="#/studio" onClick={e=>{e.preventDefault(); nav("#/studio");}} style={{textDecoration:"none",color:"var(--text)"}} className="logo">TOOLSX <span>3D</span></a>
        <nav aria-label="Main" style={{display:"flex",gap:2,flexWrap:"wrap"}}><a href="#/studio" onClick={e=>{e.preventDefault(); nav("#/studio");}} className={`navlink ${route==="studio"?"active":""}`}><Home size={15}/> Studio</a><a href="#/projects" onClick={e=>{e.preventDefault(); nav("#/projects");}} className={`navlink ${route==="projects"?"active":""}`}><FolderOpen size={15}/> Projects</a><a href="#/templates" onClick={e=>{e.preventDefault(); nav("#/templates");}} className={`navlink ${route==="templates"?"active":""}`}><Layers size={15}/> Templates</a><a href="#/help" onClick={e=>{e.preventDefault(); nav("#/help");}} className={`navlink ${route==="help"?"active":""}`}><HelpCircle size={15}/> Help</a></nav>
        <div style={{display:"flex",gap:6,alignItems:"center",marginLeft:"auto",flexWrap:"wrap"}}>
          {route==="studio" && <><input className="field" style={{width:170}} aria-label="Project name" value={projectName} onChange={e=>setProjectName(e.target.value)} /><span className="chip" aria-live="polite">{saveState}</span><button className="btn" onClick={undo} disabled={!history.length} aria-label="Undo"><Undo2 size={16}/></button><button className="btn" onClick={redo} disabled={!redoStack.length} aria-label="Redo"><Redo2 size={16}/></button><button className="btn" onClick={saveProjectNow} disabled={busy}><Save size={16}/> Save</button><button className="btn primary" onClick={()=>setShowExport(true)}><Download size={16}/> Export</button></>}
          <button className="iconbtn" aria-label="Toggle theme" onClick={()=>setTheme(theme==="dark"?"light":"dark")}>{theme==="dark"? <Sun size={18}/> : <Moon size={18}/>}</button>
        </div>
      </header>

      {route==="studio" && studio}
      {route==="projects" && projectsScreen}
      {route==="templates" && templatesScreen}
      {route==="help" && helpScreen}
      {route==="about" && legal("About TOOLSX 3D", <><p>TOOLSX 3D is a free, browser-based 3D modeling and architecture tool from AI Tools Lab India, part of ToolsX.in. It runs entirely in your browser. There is no account and no login.</p><p>Build with primitives and parametric architecture elements — walls, floors, doors, windows, columns, stairs and roofs — then export GLB, GLTF, OBJ, STL, PNG or project JSON.</p><p>There is no AI feature in this version. If AI is added later, it will be described honestly and will not be presented as something it is not.</p></>)}
      {route==="privacy" && legal("Privacy", <><p>TOOLSX 3D runs in your browser. Your models and project files stay on your device unless you choose to download or export them.</p><p>There is no account, no login and no tracking beyond what is actually used to serve the page. Projects you save are stored in this browser so you can reopen them here.</p><p>Imported files are processed in your browser. They are not uploaded by this app.</p><p>Last updated: 2026.</p></>)}
      {route==="terms" && legal("Terms", <><p>TOOLSX 3D is provided free for use in your browser. You keep ownership of the models and files you create.</p><p>Use the tool lawfully. Exported files are your responsibility. The tool is provided as-is, without warranty.</p><p>Last updated: 2026.</p></>)}
      {route==="contact" && legal("Contact", <><p>For feedback about TOOLSX 3D, visit the main ToolsX site.</p><p><a href="https://toolsx.in" target="_blank" rel="noopener">https://toolsx.in <ExternalLink size={14}/></a></p><p>Include the page you were on, what you were trying to do, and what happened. Do not send passwords or private files.</p></>)}
      {!["studio","projects","templates","help","about","privacy","terms","contact"].includes(route) && <main style={{maxWidth:720,margin:"0 auto",padding:"40px 16px",textAlign:"center"}}><h1>Page not found</h1><p style={{color:"var(--muted)"}}>That address does not exist. The Studio is always here.</p><button className="btn primary" onClick={()=>nav("#/studio")}>Go to Studio</button></main>}

      <footer style={{borderTop:"1px solid var(--border)",padding:"14px 16px",display:"flex",gap:12,flexWrap:"wrap",fontSize:12,color:"var(--muted)",background:"var(--surface)"}}>
        <span>© 2026 TOOLSX 3D · AI Tools Lab India</span><a href="#/about" onClick={e=>{e.preventDefault(); nav("#/about");}}>About</a><a href="#/privacy" onClick={e=>{e.preventDefault(); nav("#/privacy");}}>Privacy</a><a href="#/terms" onClick={e=>{e.preventDefault(); nav("#/terms");}}>Terms</a><a href="#/contact" onClick={e=>{e.preventDefault(); nav("#/contact");}}>Contact</a><a href="https://toolsx.in" target="_blank" rel="noopener">ToolsX.in <ExternalLink size={12}/></a><span style={{marginLeft:"auto"}}>Runs in your browser · No account · Files stay on your device</span>
      </footer>

      {/* mobile sheets */}
      {leftOpen && <div className="sheet" role="dialog" aria-label="Add objects"><div style={{display:"flex",justifyContent:"space-between"}}><strong>Add</strong><button className="iconbtn" onClick={()=>setLeftOpen(false)}><X size={18}/></button></div>{addButtons}<div style={{marginTop:16}}>{outliner}</div><button className="btn" style={{marginTop:14}} onClick={()=>setLeftOpen(false)}>Close</button></div>}
      {rightOpen && <div className="sheet" role="dialog" aria-label="Inspector"><div style={{display:"flex",justifyContent:"space-between"}}><strong>Inspector</strong><button className="iconbtn" onClick={()=>setRightOpen(false)}><X size={18}/></button></div>{inspector}<button className="btn" style={{marginTop:14}} onClick={()=>setRightOpen(false)}>Close</button></div>}

      {showShortcuts && <div className="modal-backdrop" role="dialog" aria-modal="true" aria-label="Shortcuts"><div className="modal"><div style={{display:"flex",justifyContent:"space-between"}}><h2 style={{margin:0}}>Shortcuts</h2><button className="iconbtn" onClick={()=>setShowShortcuts(false)}><X size={18}/></button></div><table><tbody><tr><td>W / E / R</td><td>Move / Rotate / Scale</td></tr><tr><td>Ctrl+Z</td><td>Undo</td></tr><tr><td>Ctrl+Shift+Z / Ctrl+Y</td><td>Redo</td></tr><tr><td>Ctrl+D</td><td>Duplicate</td></tr><tr><td>Ctrl+C / Ctrl+V</td><td>Copy / Paste</td></tr><tr><td>Delete</td><td>Delete selection</td></tr><tr><td>F</td><td>Frame selection</td></tr><tr><td>Esc</td><td>Deselect</td></tr></tbody></table><button className="btn primary" onClick={()=>setShowShortcuts(false)}>Close</button></div></div>}
      {showExport && <div className="modal-backdrop" role="dialog" aria-modal="true" aria-label="Export"><div className="modal"><div style={{display:"flex",justifyContent:"space-between"}}><h2 style={{margin:0}}>Export</h2><button className="iconbtn" onClick={()=>setShowExport(false)}><X size={18}/></button></div>
        <label className="lbl">Format</label><select className="field" value={exportFormat} onChange={e=>setExportFormat(e.target.value as any)}><option value="glb">GLB (binary)</option><option value="gltf">GLTF (JSON)</option><option value="obj">OBJ</option><option value="stl">STL</option><option value="png">PNG screenshot</option><option value="json">Project JSON (.toolsx3d.json)</option></select>
        <label className="lbl">Scope</label><select className="field" value={exportScope} onChange={e=>setExportScope(e.target.value as any)}><option value="all">Whole scene ({objects.length} objects)</option><option value="selected">Selection only ({selected.length} objects)</option></select>
        <p style={{fontSize:12,color:"var(--muted)"}}>Export downloads a real file to your device. PNG captures the current viewport.</p>
        <div style={{display:"flex",gap:8,marginTop:14}}><button className="btn primary" onClick={doExport}><Download size={16}/> Download</button><button className="btn" onClick={()=>setShowExport(false)}>Cancel</button></div>
        <div style={{marginTop:16,borderTop:"1px solid var(--border)",paddingTop:12}}><strong>Import</strong><p style={{fontSize:13,color:"var(--muted)"}}>GLB, GLTF, OBJ, STL or project JSON · max 50 MB. Drop a file on the viewport or choose it here.</p><label className="btn" style={{cursor:"pointer"}}><Upload size={16}/> Choose file<input type="file" accept=".glb,.gltf,.obj,.stl,.json" style={{display:"none"}} onChange={e=>{ const f=e.target.files?.[0]; if(f){ importFile(f); setShowExport(false); } }} /></label></div>
      </div></div>}
      {confirmClear && <div className="modal-backdrop" role="dialog" aria-modal="true" aria-label="Clear scene"><div className="modal"><h2 style={{marginTop:0}}>Clear the scene?</h2><p>This deletes all {objects.length} objects in the current scene. It can be undone with Ctrl+Z.</p><div style={{display:"flex",gap:8}}><button className="btn danger" onClick={clearScene}>Clear scene</button><button className="btn" onClick={()=>setConfirmClear(false)}>Cancel</button></div></div></div>}
      {toast && <Toast msg={toast} />}
      <div aria-live="polite" style={{position:"absolute",width:1,height:1,overflow:"hidden",clip:"rect(0,0,0,0)"}}>{toast}</div>
    </div>
    </Boundary>
  );
}
